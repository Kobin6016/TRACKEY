import React, { useEffect, useState } from 'react';
import { Alert, Appearance, FlatList, SafeAreaView, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabase: SupabaseClient | null = process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY
  ? createClient(process.env.EXPO_PUBLIC_SUPABASE_URL, process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY) : null;
const API = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4242';
const products = [
  { id: 'kt-mini', name: 'KeyTrack Mini', price: 39.99, description: 'Compact GPS-enabled keyholder with location history.' },
  { id: 'kt-pro', name: 'KeyTrack Pro', price: 59.99, description: 'Extended battery and precision location updates.' }
];

export default function App() {
  const [dark, setDark] = useState(Appearance.getColorScheme() === 'dark');
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [tab, setTab] = useState('Shop'); const [orders, setOrders] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]); const [points, setPoints] = useState(0);
  const [selected, setSelected] = useState(products[0]);
  const [shipping, setShipping] = useState({ name: '', address: '', city: '', phone: '' });
  const c = dark ? theme.dark : theme.light;

  useEffect(() => {
    AsyncStorage.multiGet(['keytrack_orders','keytrack_reviews','keytrack_points']).then(rows => {
      setOrders(JSON.parse(rows[0][1] || '[]')); setReviews(JSON.parse(rows[1][1] || '[]')); setPoints(Number(rows[2][1] || 0));
    });
    Notifications.requestPermissionsAsync().catch(()=>{});
    if (supabase) supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
  }, []);

  async function auth(mode: 'signup'|'signin') {
    if (!supabase) return Alert.alert('Setup required', 'Add your Supabase URL and anon key to mobile/.env.');
    const result = mode === 'signup' ? await supabase.auth.signUp({ email, password }) : await supabase.auth.signInWithPassword({ email, password });
    if (result.error) Alert.alert('Account', result.error.message); else { setUser(result.data.user); Alert.alert('Account', mode === 'signup' ? 'Check your email to verify your account.' : 'Signed in.'); }
  }
  async function buy() {
    if (!user) return Alert.alert('Sign in required', 'Create an account or sign in before ordering.');
    if (!shipping.name || !shipping.address || !shipping.city || !shipping.phone) return Alert.alert('Shipping details', 'Complete all shipping fields first.');
    try {
      const res = await fetch(`${API}/create-payment-intent`, { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${user.id}`}, body:JSON.stringify({ productId:selected.id, shipping }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Could not start payment.');
      Alert.alert('Payment setup', 'PaymentIntent created. Connect Stripe PaymentSheet in this step before accepting live payments.');
      const next = [{ id: data.orderId || `KT-${Date.now()}`, product:selected.name, status:'Awaiting payment confirmation', trackingId:'DEMO-TRACKER-001', createdAt:new Date().toISOString() }, ...orders];
      setOrders(next); await AsyncStorage.setItem('keytrack_orders', JSON.stringify(next));
    } catch(e:any) { Alert.alert('Checkout', e.message); }
  }
  async function addReview() {
    const row = { product:selected.name, rating:5, text:'Great design and easy to use.', date:new Date().toISOString() };
    const next=[row,...reviews]; setReviews(next); await AsyncStorage.setItem('keytrack_reviews',JSON.stringify(next)); Alert.alert('Review saved','Thanks for sharing your feedback.');
  }
  async function enableTwoFactor() {
    if (!supabase || !user) return Alert.alert('Account setup','Sign in and configure Supabase Auth first.');
    const { data, error } = await supabase.auth.mfa.enroll({ factorType:'totp', friendlyName:'KeyTrack authenticator' });
    if (error) Alert.alert('Two-factor authentication',error.message); else Alert.alert('Scan authenticator QR', `Factor created. QR data: ${data.totp.uri}\nImplement QR display and verify the six-digit code with supabase.auth.mfa.challengeAndVerify before marking MFA enabled.`);
  }
  async function notifyDemo() { await Notifications.scheduleNotificationAsync({ content:{title:'KeyTrack location alert',body:'Your demo keyholder has moved.'}, trigger:null }); }
  const card = (children:any) => <View style={[styles.card,{backgroundColor:c.card,borderColor:c.border}]}>{children}</View>;
  const button = (label:string, onPress:()=>void) => <TouchableOpacity style={[styles.button,{backgroundColor:c.accent}]} onPress={onPress}><Text style={styles.buttonText}>{label}</Text></TouchableOpacity>;
  const field = (value:string, onChange:(v:string)=>void, placeholder:string, secure=false) => <TextInput value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={c.muted} secureTextEntry={secure} style={[styles.input,{color:c.text,borderColor:c.border,backgroundColor:c.input}]} />;

  return <SafeAreaView style={[styles.root,{backgroundColor:c.bg}]}>
    <View style={styles.header}><View><Text style={[styles.brand,{color:c.text}]}>KeyTrack</Text><Text style={{color:c.muted}}>Your keys. Within reach.</Text></View><View style={styles.row}><Text style={{color:c.text}}>Dark</Text><Switch value={dark} onValueChange={setDark}/></View></View>
    {!user ? <ScrollView contentContainerStyle={styles.content}>{card(<><Text style={[styles.heading,{color:c.text}]}>Welcome</Text><Text style={{color:c.muted,marginBottom:12}}>Sign in or create an account to manage orders and trackers.</Text>{field(email,setEmail,'Email address')}{field(password,setPassword,'Password',true)}{button('Sign in',()=>auth('signin'))}{button('Create account',()=>auth('signup'))}</>)}</ScrollView> : <>
      <View style={styles.tabs}>{['Shop','Orders','Map','Account'].map(t=><TouchableOpacity key={t} onPress={()=>setTab(t)}><Text style={[styles.tab,{color:tab===t?c.accent:c.muted}]}>{t}</Text></TouchableOpacity>)}</View>
      <ScrollView contentContainerStyle={styles.content}>
        {tab==='Shop' && <>{products.map(p=>card(<TouchableOpacity onPress={()=>setSelected(p)} key={p.id}><Text style={[styles.heading,{color:c.text}]}>{p.name} {selected.id===p.id?'✓':''}</Text><Text style={{color:c.muted}}>{p.description}</Text><Text style={[styles.price,{color:c.text}]}>${p.price.toFixed(2)}</Text></TouchableOpacity>))}{card(<><Text style={[styles.heading,{color:c.text}]}>Delivery details</Text>{field(shipping.name,v=>setShipping({...shipping,name:v}),'Full name')}{field(shipping.address,v=>setShipping({...shipping,address:v}),'Street address')}{field(shipping.city,v=>setShipping({...shipping,city:v}),'City / Region')}{field(shipping.phone,v=>setShipping({...shipping,phone:v}),'Phone number')}{button('Continue to secure checkout',buy)}</>)}</>}
        {tab==='Orders' && <>{card(<><Text style={[styles.heading,{color:c.text}]}>Order dashboard</Text><Text style={{color:c.muted}}>Order status and shipment tracking appear here.</Text></>)}{orders.length===0? <Text style={{color:c.muted}}>No orders yet.</Text>:orders.map(o=>card(<><Text style={[styles.heading,{color:c.text}]}>{o.product}</Text><Text style={{color:c.muted}}>Order {o.id}</Text><Text style={{color:c.accent}}>{o.status}</Text><Text style={{color:c.muted}}>Tracker: {o.trackingId}</Text></>))}</>}
        {tab==='Map' && <>{card(<><Text style={[styles.heading,{color:c.text}]}>Keyholder location</Text><Text style={{color:c.muted}}>Demo coordinates only. Connect a real GPS device telemetry feed to show live location.</Text></>)}<MapView style={styles.map} initialRegion={{latitude:5.1053,longitude:-1.2466,latitudeDelta:0.04,longitudeDelta:0.04}}><Marker coordinate={{latitude:5.1053,longitude:-1.2466}} title="Demo keyholder" description="Replace with authenticated device telemetry"/></MapView>{button('Test location alert',notifyDemo)}</>}
        {tab==='Account' && <>{card(<><Text style={[styles.heading,{color:c.text}]}>Account security</Text><Text style={{color:c.muted}}>Signed in as {user.email}</Text>{button('Set up two-factor authentication',enableTwoFactor)}{button('Sign out',async()=>{await supabase?.auth.signOut();setUser(null);})}</>)}{card(<><Text style={[styles.heading,{color:c.text}]}>Loyalty rewards</Text><Text style={{color:c.accent,fontSize:28,fontWeight:'800'}}>{points} points</Text><Text style={{color:c.muted}}>Earn points on completed purchases. Award points only after verified payment webhooks.</Text></>)}{card(<><Text style={[styles.heading,{color:c.text}]}>Customer reviews</Text>{button('Add a 5-star sample review',addReview)}{reviews.map((r,i)=><View key={i} style={{paddingVertical:8}}><Text style={{color:c.text}}>{r.product} · ★★★★★</Text><Text style={{color:c.muted}}>{r.text}</Text></View>)}</>)}</>}
      </ScrollView>
    </>}
    <Text style={[styles.footer,{color:c.muted}]}>KeyTrack · Secure connected accessories</Text>
  </SafeAreaView>;
}
const theme:any={light:{bg:'#F4F6FA',card:'#FFFFFF',text:'#111827',muted:'#667085',border:'#E4E7EC',input:'#FFFFFF',accent:'#2563EB'},dark:{bg:'#0B1220',card:'#121D2E',text:'#F8FAFC',muted:'#9AA9BD',border:'#26364D',input:'#0D1727',accent:'#60A5FA'}};
const styles=StyleSheet.create({root:{flex:1},header:{padding:20,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},brand:{fontSize:28,fontWeight:'900'},row:{flexDirection:'row',alignItems:'center',gap:6},tabs:{flexDirection:'row',justifyContent:'space-around',paddingVertical:12,borderTopWidth:1,borderBottomWidth:1,borderColor:'#26364D'},tab:{fontWeight:'700'},content:{padding:16,gap:12},card:{padding:16,borderRadius:16,borderWidth:1,gap:10},heading:{fontSize:19,fontWeight:'800'},price:{fontSize:20,fontWeight:'800',marginTop:6},input:{borderWidth:1,borderRadius:10,padding:12,marginTop:4},button:{padding:14,borderRadius:10,alignItems:'center',marginTop:6},buttonText:{color:'#FFFFFF',fontWeight:'800'},map:{height:360,borderRadius:16,overflow:'hidden'},footer:{textAlign:'center',padding:10,fontSize:11}});
