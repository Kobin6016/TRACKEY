require('dotenv').config();
const express = require('express'); const cors = require('cors'); const Stripe = require('stripe');
const app = express(); const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
app.use(cors());
// Stripe requires the raw request body for signature verification.
app.post('/stripe-webhook', express.raw({type:'application/json'}), (req,res)=>{
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.status(503).send('Stripe webhook not configured');
  let event; try { event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET); }
  catch(err) { return res.status(400).send(`Webhook Error: ${err.message}`); }
  if (event.type === 'payment_intent.succeeded') {
    // TODO: verify order ownership, mark paid, award loyalty points, and enqueue shipment workflow in your database.
  }
  res.json({received:true});
});
app.use(express.json());
// DEVELOPMENT ONLY: replace with Supabase JWT verification (JWKS) and ownership checks.
function requireAuth(req,res,next){ const token=(req.headers.authorization||'').replace(/^Bearer\s+/,''); if(!token) return res.status(401).json({error:'Authentication required'}); req.userId=token; next(); }
const catalog={'kt-mini':3999,'kt-pro':5999};
app.post('/create-payment-intent',requireAuth,async(req,res)=>{
  try {
    if(!stripe) return res.status(503).json({error:'Stripe is not configured. Add STRIPE_SECRET_KEY.'});
    const amount=catalog[req.body.productId]; if(!amount) return res.status(400).json({error:'Unknown product'});
    const {shipping}=req.body; if(!shipping?.name||!shipping?.address||!shipping?.city||!shipping?.phone) return res.status(400).json({error:'Complete shipping information.'});
    const intent=await stripe.paymentIntents.create({amount,currency:'usd',automatic_payment_methods:{enabled:true},metadata:{userId:req.userId,productId:req.body.productId}});
    res.json({clientSecret:intent.client_secret,paymentIntentId:intent.id,orderId:`KT-${Date.now()}`});
  } catch(e){res.status(500).json({error:e.message});}
});
app.get('/health',(req,res)=>res.json({ok:true,service:'KeyTrack API'}));
app.listen(process.env.PORT||4242,()=>console.log(`KeyTrack API listening on ${process.env.PORT||4242}`));
