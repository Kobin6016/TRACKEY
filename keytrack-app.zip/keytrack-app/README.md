# KeyTrack starter app

A cross-platform Expo (iOS/Android) starter for selling GPS-enabled keyholders. It includes a responsive mobile UI, Supabase email authentication, an account dashboard, order list, product reviews, loyalty points display, dark mode, local persistence, local push-notification demo, map screen, a Stripe PaymentIntent API, and a Supabase TOTP MFA enrollment starting point.

## Important product and security boundaries

This is a development starter, not a production-ready commerce or tracking system. The map currently shows a **demo marker in Cape Coast**. A keyholder cannot be tracked by software alone: the physical product needs a GPS/GNSS receiver, cellular or other uplink (for example LTE-M/NB-IoT), SIM/eSIM and a backend device protocol. Integrate the manufacturer's authenticated telemetry API or your own MQTT/HTTPS ingestion service, then replace the demo marker with authorized device coordinates and timestamps. For a small key fob, Bluetooth trackers are often more practical than standalone GPS, but they do not provide universal real-time GPS tracking.

The checkout API creates a PaymentIntent but the mobile UI does not yet present Stripe PaymentSheet or confirm payment. Do not accept live orders until PaymentSheet, webhook-driven order state, tax/shipping calculations, refunds, and idempotency are implemented. The server's `requireAuth` middleware is explicitly a development stub and trusts the bearer token as a user ID. Replace it with verified Supabase JWT validation and database authorization before deployment.

The current local reviews and loyalty points are demo persistence only. Move them to database tables with row-level security. The push notification is a local demo; production location alerts require device events, a notification worker, Expo push tokens, and user consent/preferences. Offline mode currently preserves a few demo records locally; secure sync/conflict handling and queued checkout are not implemented. Do not store card details in the app; use Stripe's native PaymentSheet.

End-to-end encryption is **not claimed** by this starter. TLS protects network transport and Supabase/Stripe provide their own security controls, but server-side order processing and location alerts require the backend to access relevant data. If true E2EE is required, design client-held keys, encrypted location payloads, recovery/key rotation, and a threat model before implementation; this limits server-side processing and account recovery. Never put encryption secrets in the mobile bundle.

## Setup

### 1. Supabase
1. Create a Supabase project.
2. Enable email/password authentication and email verification.
3. Enable TOTP MFA in Authentication settings.
4. Create database tables for `profiles`, `products`, `orders`, `order_items`, `devices`, `device_locations`, `reviews`, `loyalty_ledger`, and `push_tokens`.
5. Enable Row Level Security and write policies so customers can read/write only their own records. Device ingestion should use a server-only service role, never the mobile anon key.
6. Copy the project URL and anon key to `mobile/.env` using `.env.example`.

### 2. Mobile app
```bash
cd mobile
npm install
npx expo start
```
Use an Expo development build for native Stripe and map functionality. Set `EXPO_PUBLIC_API_URL` to the reachable API host (not `localhost` when testing on a physical phone).

### 3. API and Stripe
```bash
cd server
npm install
cp .env.example .env
# Add Stripe test secret and webhook secret
npm start
```
Configure a Stripe webhook endpoint at `/stripe-webhook` for `payment_intent.succeeded`, `payment_intent.payment_failed`, and any refund events you support. Use Stripe test mode first. Keep secret keys on the server only.

## Production checklist
- Verify Supabase access tokens server-side; never use the demo middleware.
- Complete Stripe PaymentSheet and webhook-driven order fulfilment.
- Add database schema, RLS policies, audit logs, rate limiting, input validation, and secrets management.
- Connect certified tracker hardware and authenticated device telemetry; add device ownership/pairing and location-sharing consent.
- Store location with retention limits; provide pause tracking, revoke access, and delete/export controls.
- Implement remote push delivery and background location alert rules.
- Implement TOTP QR display and challenge verification; require MFA for sensitive actions.
- Implement encrypted local storage, robust offline sync, conflict resolution, and explicit stale-location indicators.
- Have a security review and privacy/legal review for the countries where you sell and track devices.

## Suggested production architecture
Expo app → Supabase Auth (MFA) → API gateway → orders/Stripe; tracker → authenticated MQTT/HTTPS ingestion → location database/stream → push worker → Expo Push Service. Use Postgres RLS for customer access and a separate privileged service for device ingestion.

A starter database definition is included at `supabase/schema.sql`. Apply it only after reviewing the schema and policies. Privileged writes for orders, device telemetry, and loyalty balances are intentionally excluded from client access and must be performed by a verified backend.
