-- Starter schema. Review policies and adapt before production deployment.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id text primary key,
  name text not null,
  description text,
  price_minor integer not null check (price_minor >= 0),
  active boolean not null default true
);
insert into public.products(id,name,description,price_minor) values
('kt-mini','KeyTrack Mini','Compact GPS-enabled keyholder',3999),
('kt-pro','KeyTrack Pro','Extended battery and precision location updates',5999)
on conflict (id) do nothing;
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  status text not null default 'pending_payment',
  stripe_payment_intent_id text unique,
  shipping_name text not null,
  shipping_address text not null,
  shipping_city text not null,
  shipping_phone text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id text not null references public.products(id),
  quantity integer not null default 1 check (quantity > 0),
  unit_price_minor integer not null
);
create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id),
  owner_id uuid not null references auth.users(id),
  device_serial text unique not null,
  nickname text,
  created_at timestamptz not null default now()
);
create table if not exists public.device_locations (
  id bigint generated always as identity primary key,
  device_id uuid not null references public.devices(id) on delete cascade,
  latitude double precision not null check(latitude between -90 and 90),
  longitude double precision not null check(longitude between -180 and 180),
  accuracy_m double precision,
  recorded_at timestamptz not null,
  received_at timestamptz not null default now()
);
create index if not exists device_locations_latest_idx on public.device_locations(device_id, recorded_at desc);
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  product_id text not null references public.products(id),
  rating integer not null check(rating between 1 and 5),
  body text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.loyalty_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  order_id uuid references public.orders(id),
  points integer not null,
  reason text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.push_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  expo_push_token text not null,
  created_at timestamptz not null default now(),
  unique(user_id, expo_push_token)
);

alter table public.profiles enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.devices enable row level security;
alter table public.device_locations enable row level security;
alter table public.reviews enable row level security;
alter table public.loyalty_ledger enable row level security;
alter table public.push_tokens enable row level security;
alter table public.products enable row level security;

create policy "read active products" on public.products for select using (active = true);
create policy "customers manage own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "customers read own orders" on public.orders for select using (auth.uid() = user_id);
create policy "customers read own order items" on public.order_items for select using (exists(select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy "customers read own devices" on public.devices for select using (auth.uid() = owner_id);
create policy "customers read own device locations" on public.device_locations for select using (exists(select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid()));
create policy "public read reviews" on public.reviews for select using (true);
create policy "customers create own reviews" on public.reviews for insert with check (auth.uid() = user_id);
create policy "customers read own loyalty" on public.loyalty_ledger for select using (auth.uid() = user_id);
create policy "customers manage own push tokens" on public.push_tokens for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Deliberately no client INSERT/UPDATE policy for orders, devices, device_locations or loyalty_ledger.
-- Write these through a verified server using the Supabase service role after validating ownership/payment/device signatures.
